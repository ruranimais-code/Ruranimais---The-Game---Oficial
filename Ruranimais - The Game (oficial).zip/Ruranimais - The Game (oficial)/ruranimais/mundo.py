
#Desenho do mundo de jogo (cenário, obstáculos, jogador, parede de fogo e efeitos)

import math
import random

import pygame

import config as C
from assets import fps_da_animacao, quadro_da_animacao, quadros_do_bichinho

COR_MIOLO_FOGO = (251, 182, 46)


class Particula:
    __slots__ = ("x", "y", "vx", "vy", "vida", "vida0", "cor", "tam", "grav", "mundo")

    def __init__(self, x, y, vx, vy, vida, cor, tam=4, grav=900.0, mundo=True):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.vida = self.vida0 = vida
        self.cor, self.tam, self.grav, self.mundo = cor, tam, grav, mundo


class Mundo:
    def __init__(self, imagens, cenario, animal="cachorro", skin="caramelo"):
        self.img = imagens
        self.cenario = cenario
        self.animal, self.skin = animal, skin
        self.quadros = quadros_do_bichinho(imagens, animal, skin)   # animação -> quadros
        self.particulas = []
        self.t = 0.0
        self.flash = 0.0           # clarão vermelho ao bater
        self.textos = []           # [x_mundo, y, texto, vida]
        self.sombra = pygame.Surface((70, 14), pygame.SRCALPHA)
        pygame.draw.ellipse(self.sombra, (0, 0, 0, 90), (0, 0, 70, 14))
        self.vermelho = pygame.Surface((C.LARGURA, C.ALTURA))
        self.vermelho.fill((220, 30, 20))

    # ------------------------------------------------------------ eventos -> efeitos
    def reagir(self, nome, d, partida):
        j = partida.j
        if nome == "pouso":
            for _ in range(6):
                self.particulas.append(Particula(
                    j.x + random.uniform(-15, 15), j.y - 2, random.uniform(-90, 40),
                    random.uniform(-120, -30), 0.35, (225, 215, 190), 4, 300))
        elif nome == "batida":
            self.flash = 0.35
            cores = {"caixote": [(168, 105, 47), (122, 74, 32), (220, 162, 92)],
                     "barreira": [(214, 40, 40), (244, 241, 234)],
                     "espinhos": [(201, 209, 217), (135, 147, 160)]}[d["tipo"]]
            for _ in range(14):
                self.particulas.append(Particula(
                    d["x"] + random.uniform(0, 60), d["y"] + random.uniform(0, 40),
                    random.uniform(-160, 260), random.uniform(-460, -100), 0.8,
                    random.choice(cores), random.randint(5, 9), 1400))
            self.textos.append([j.x - 10, j.y - 130, "Ai!", 0.8])
        elif nome == "comida":
            for _ in range(7):
                self.particulas.append(Particula(
                    d["x"], d["y"], random.uniform(-150, 150), random.uniform(-260, -40),
                    0.45, random.choice([(255, 220, 60), (255, 255, 255), (250, 160, 50)]),
                    random.randint(3, 6), 700))
            self.textos.append([d["x"] - 14, d["y"] - 26, f"+{C.VALOR_COMIDA}", 0.7])

    # ---------------------------------------------------------------- atualização
    def atualizar(self, dt, partida):
        self.t += dt
        self.flash = max(0.0, self.flash - dt)
        for p in self.particulas:
            p.vida -= dt
            p.vy += p.grav * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
        self.particulas = [p for p in self.particulas if p.vida > 0]
        for tx in self.textos:
            tx[3] -= dt
            tx[1] -= 40 * dt
        self.textos = [t for t in self.textos if t[3] > 0]
        # brasas saindo da parede de fogo
        if partida and random.random() < 0.6:
            frente = partida.j.x - partida.dist_fogo
            self.particulas.append(Particula(
                frente - random.uniform(0, 30), random.uniform(60, C.ALTURA - 20),
                random.uniform(60, 200), random.uniform(-80, -20), random.uniform(0.5, 1.1),
                random.choice([(255, 200, 60), (255, 120, 30), (255, 240, 160)]),
                random.choice([2, 3, 4]), -40))

    # --------------------------------------------------------------------- desenho
    def desenhar(self, tela, partida, fogo_extra=0.0, piscar=True):
        cam = partida.camera_x
        self.cenario.desenhar(tela, cam)
        j = partida.j

        # obstáculos
        for o in partida.obstaculos:
            sx = int(o.x - cam)
            if sx > C.LARGURA + 20 or sx + o.w < -20:
                continue
            if not o.ativo:
                continue          # quebrado: sobraram só as partículas
            tela.blit(getattr(self.img, o.tipo), (sx, int(o.y)))

        # comidas (flutuam suavemente)
        for c in partida.comidas:
            if not c.ativo:
                continue
            sx = c.cx - cam
            if sx < -40 or sx > C.LARGURA + 40:
                continue
            bal = math.sin(self.t * 4.0 + c.cx * 0.02) * 5
            spr = self.img.comidas[c.variante]
            tela.blit(spr, (int(sx - spr.get_width() / 2), int(c.cy - spr.get_height() / 2 + bal)))

        # jogador
        self._desenhar_jogador(tela, partida, cam, piscar)

        # partículas (no espaço do mundo)
        for p in self.particulas:
            f = max(0.0, p.vida / p.vida0)
            t = max(1, int(p.tam * (0.5 + 0.5 * f)))
            pygame.draw.rect(tela, p.cor, (int(p.x - cam), int(p.y), t, t))

        for x, y, txt, vida in self.textos:
            self._texto_flutuante(tela, txt, int(x - cam), int(y), vida)

        self._desenhar_fogo(tela, partida, fogo_extra)

        # clarão vermelho ao bater / perigo
        alpha = 0
        if self.flash > 0:
            alpha = int(140 * self.flash / 0.35)
        if partida.dist_fogo - fogo_extra < 130 and not partida.fim:
            alpha = max(alpha, int(45 + 30 * math.sin(self.t * 11)))
        if alpha > 0:
            self.vermelho.set_alpha(alpha)
            tela.blit(self.vermelho, (0, 0))

    def _texto_flutuante(self, tela, txt, x, y, vida):
        from telas import texto
        texto(tela, txt, (x, y), 34, (255, 240, 120), centro=True, contorno=C.COR_TINTA)

    # ------------------------------------------------------------------ jogador
    def _escolher_quadro(self, j):
        """Escolhe o quadro do bichinho conforme o que ele está fazendo."""
        q = self.quadros
        if j.deslizando:
            return quadro_da_animacao(q["deslize"], j.t_deslize, fps_da_animacao(self.img, self.animal, "deslize"))
        if not j.no_chao:
            quadros = q["pulo"]
            n = len(quadros)
            # progresso do pulo: 0 = decolando (subindo rápido) ... 1 = caindo rápido
            p = (j.vy + C.VEL_PULO) / (2 * C.VEL_PULO)
            p = max(0.0, min(1.0, p))
            return quadros[min(max(n - 2, 0), int(p * max(n - 1, 1)))]
        if j.t_pouso > 0 and len(q["pulo"]) > 1:
            return q["pulo"][-1]
        return quadro_da_animacao(q["correr"], j.t_anim, fps_da_animacao(self.img, self.animal, "correr"))

    def _desenhar_jogador(self, tela, partida, cam, piscar):
        j = partida.j
        sx = C.JOGADOR_TELA_X
        # sombra no chão (ou em cima do caixote)
        chao_y = j.apoio.topo if j.apoio else C.CHAO_Y
        alt = max(0.0, chao_y - j.y)
        if alt < 200 or j.apoio:
            tela.blit(self.sombra, (sx - 35, int(chao_y) - 8))
        if j.invulneravel > 0 and piscar and int(self.t * 16) % 2 == 0:
            return
        spr = self._escolher_quadro(j)
        tela.blit(spr, (int(sx - spr.get_width() / 2), int(j.y - spr.get_height())))

    # --------------------------------------------------------------------- fogo
    def _desenhar_fogo(self, tela, partida, extra):
        frente = int(C.JOGADOR_TELA_X - (partida.dist_fogo - extra))
        if frente <= 0 and partida.dist_fogo - extra > 0:
            # fogo ainda fora da tela: só o brilho tímido
            if frente > -150:
                tela.blit(self.img.brilho_fogo, (frente, 0))
            return
        x0 = frente - 64
        if x0 > 0:
            pygame.draw.rect(tela, COR_MIOLO_FOGO, (0, 0, x0, C.ALTURA))
        quadro = self.img.fogo[int(self.t * 12) % len(self.img.fogo)]
        for y in range(0, C.ALTURA, 64):
            tela.blit(quadro, (x0, y))
        tela.blit(self.img.brilho_fogo, (frente, 0))
