# Configurações do jogo

import pygame

# ----------------------------------------------------------------- janela
LARGURA, ALTURA = 960, 540
FPS = 60
TITULO = "ruranimais - The Game"

# ------------------------------------------------------------------ teclas
# Cada ação aceita várias teclas. Para trocar, edite só esta tabela.
TECLAS = {
    "pular":    [pygame.K_UP, pygame.K_w, pygame.K_SPACE],
    "deslizar": [pygame.K_DOWN, pygame.K_s],
    "pausa":    [pygame.K_p, pygame.K_ESCAPE],
}
NOMES_TECLAS = {
    "pular": "Seta cima / W / Espaço",
    "deslizar": "Seta baixo / S",
    "pausa": "P / Esc",
}

# ------------------------------------------------------------------- mundo
CHAO_Y = 470              # linha do chão (y dos pés do jogador e dos obstáculos)
JOGADOR_TELA_X = 300      # posição fixa do jogador na tela (a câmera segue ele)
PX_POR_METRO = 64         # conversão de pixels para metros

# --------------------------------------------------------------- velocidade
VELOCIDADE_INICIAL = 380.0   # px/s
VELOCIDADE_MAXIMA = 520.0
GANHO_POR_METRO = 0.07       # quanto a velocidade sobe a cada metro percorrido

# ------------------------------------------------------------------ jogador
GRAVIDADE = 2300.0
VEL_PULO = 840.0             # impulso inicial (pico de ~153 px de altura)
CORTE_PULO = 0.5             # soltar o botão cedo corta o pulo (pulo variável)
QUEDA_RAPIDA = 1500.0        # aceleração extra ao apertar "deslizar" no ar
TEMPO_COYOTE = 0.08          # tolerância para pular logo depois de sair de uma borda
TEMPO_BUFFER_PULO = 0.12     # tolerância para apertar pular um pouco antes de pousar

HITBOX_EM_PE = (46, 72)      # largura, altura (menor que o desenho do bichinho: perdoa quase-batidas)
HITBOX_DESLIZE = (76, 34)    # precisa caber no vão de 51 px sob a barreira
DESLIZE_MAX = 0.9            # segundos máximos deslizando
DESLIZE_RECARGA = 0.15

# bichinho: os quadros têm 128x128 px, com os pés na borda de baixo e o corpo no meio
SPRITE_TAM = 128

# -------------------------------------------------------------- parede de fogo
FOGO_DIST_INICIAL = 270.0    # distância (px) entre o fogo e o jogador no começo
FOGO_DIST_MAXIMA = 310.0
FOGO_AVANCO = 5.0            # px/s que o fogo ganha sozinho
FOGO_PENALIDADE = 110.0      # quanto o fogo se aproxima a cada batida
FOGO_BONUS_COMIDA = 6.0      # quanto o fogo recua a cada comida pega (medido com o robô: 12 deixava o fogo inofensivo)
FOGO_DISTANCIA_MORTE = 20.0  # fogo a essa distância ou menos = fim de jogo
INVULNERAVEL = 1.0           # segundos sem tomar dano após uma batida

# -------------------------------------------------------------- obstáculos
CAIXOTE = (66, 66)
ESPINHOS = (60, 36)
BARREIRA = (102, 72)

# ------------------------------------------------------------------- comidas
COMIDA_TAM = 44              # tamanho do desenho (px)
COMIDA_HITBOX = 36           # área que encosta no jogador (px)
COMIDA_VARIANTES = 6         # quantos desenhos de comida existem (comida_0.png ... comida_5.png)
VALOR_COMIDA = 1             # quanto cada comida vale em "moedas" para a loja
COMIDA_ESPACO = 46           # distância entre comidas de uma mesma fileira

# ---------------------------------------------------- ciclo de cenários
# inicial -> 2 -> 3 -> (4,5,4,5... por METROS_MIOLO) -> 3 -> inicial -> ...
METROS_MIOLO = 400
FAIXA_TRANSICAO = 120
LARGURA_CORPO_CENARIO = 745

# --------------------------------------------------------------- animações (quadros/s)
FPS_CORRER = 12
FPS_DESLIZE = 10

# --------------------------------------------------------------------- áudio
VOLUME_MUSICA = 0.35
VOLUME_EFEITOS = 0.6

# ------------------------------------------------------------------- paleta
COR_CREME = (250, 240, 212)
COR_CREME_ESC = (233, 208, 156)
COR_VERDE = (66, 125, 28)
COR_VERDE_ESC = (38, 84, 20)
COR_TINTA = (40, 30, 60)
COR_LARANJA = (242, 138, 29)
COR_DESTAQUE = (255, 204, 51)
COR_VERMELHO = (200, 50, 40)
