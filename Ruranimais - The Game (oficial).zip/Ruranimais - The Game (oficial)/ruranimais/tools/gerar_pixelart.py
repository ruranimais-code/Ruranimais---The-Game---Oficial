
# Gera os pixel arts 

import math
import os
import random
from PIL import Image, ImageDraw

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAIDA = os.path.join(RAIZ, "assets", "objetos")
ESC = 3  # ampliação dos obstáculos/animais (1 pixel de arte = 3 pixels na tela)


def hexa(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


CONTORNO = hexa("2a1a12")


def novo(w, h):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)


def salvar(im, nome, esc=ESC):
    im = im.resize((im.width * esc, im.height * esc), Image.NEAREST)
    im.save(os.path.join(SAIDA, nome))
    return im


# ---------------------------------------------------------------- caixote
def caixote():
    w = h = 22
    im, d = novo(w, h)
    mad, mad_esc, mad_cl = hexa("a8692f"), hexa("7a4a20"), hexa("dca25c")
    d.rectangle([0, 0, w - 1, h - 1], fill=CONTORNO)
    d.rectangle([1, 1, w - 2, h - 2], fill=mad)
    d.rectangle([1, 1, w - 2, 3], fill=mad_cl)          # topo plano e mais claro
    for y in (8, 14):                                    # tábuas
        d.line([1, y, w - 2, y], fill=mad_esc)
    d.rectangle([1, 1, 3, h - 2], fill=mad_esc)          # montantes laterais
    d.rectangle([w - 4, 1, w - 2, h - 2], fill=mad_esc)
    d.line([3, 4, w - 4, h - 3], fill=mad_esc)           # travessa em X
    d.line([w - 4, 4, 3, h - 3], fill=mad_esc)
    d.line([2, 1, w - 3, 1], fill=hexa("f0c487"))
    for x, y in ((2, 2), (w - 3, 2), (2, h - 3), (w - 3, h - 3)):  # pregos
        d.point((x, y), fill=hexa("d9dde3"))
    return salvar(im, "caixote.png")


# ---------------------------------------------------------------- espinhos
def espinhos():
    w, h = 20, 12
    im, d = novo(w, h)
    d.rectangle([0, h - 3, w - 1, h - 1], fill=CONTORNO)
    d.rectangle([1, h - 3, w - 2, h - 2], fill=hexa("4b5563"))
    for i in range(4):
        x0 = 1 + i * 5
        pts = [(x0, h - 4), (x0 + 2, 0), (x0 + 4, h - 4)]
        d.polygon(pts, fill=CONTORNO)
        d.polygon([(x0 + 1, h - 4), (x0 + 2, 2), (x0 + 3, h - 4)], fill=hexa("c9d1d9"))
        d.line([(x0 + 2, 2), (x0 + 3, h - 4)], fill=hexa("8793a0"))
    return salvar(im, "espinhos.png")


# ---------------------------------------------------------------- barreira
def barreira():
    w, h = 34, 24
    im, d = novo(w, h)
    verm, branco = hexa("d62828"), hexa("f4f1ea")
    # pernas
    for x in (3, w - 6):
        d.rectangle([x, 6, x + 2, h - 1], fill=CONTORNO)
        d.rectangle([x + 1, 6, x + 1, h - 1], fill=hexa("b8bec7"))
    # tábua listrada
    d.rectangle([0, 1, w - 1, 7], fill=CONTORNO)
    for x in range(1, w - 1):
        for y in range(2, 7):
            listra = ((x + y) // 3) % 2
            d.point((x, y), fill=verm if listra == 0 else branco)
    # luzes amarelas nas pontas
    for x in (1, w - 4):
        d.rectangle([x, 0, x + 2, 1], fill=hexa("ffd23f"))
    return salvar(im, "barreira.png")


# ---------------------------------------------------------------- fogo
PALETA_FOGO = [hexa(c) for c in ("7a1a10", "b8281a", "e8541a", "f98d1f", "ffc83a", "fff0a0")]
MIOLO = hexa("fbb62e")


def fogo(quadros=8, tam=32, esc=2):
    """Faixa vertical de fogo que se repete sem emenda. Sólido à esquerda,
    chamas avançando para a direita."""
    sheet = Image.new("RGBA", (tam * quadros * esc, tam * esc), (0, 0, 0, 0))
    rnd = random.Random(7)
    for f in range(quadros):
        im, _ = novo(tam, tam)
        px = im.load()
        fase = f / quadros
        for y in range(tam):
            t = y / tam
            borda = (19
                     + 5 * math.sin(2 * math.pi * (t - fase))
                     + 3 * math.sin(2 * math.pi * (2 * t + 2 * fase) + 1.0)
                     + 2 * math.sin(2 * math.pi * (4 * t - 3 * fase) + 2.0))
            for x in range(tam):
                prof = borda - x          # quanto dentro do fogo
                if prof < 0:
                    continue
                if prof >= 15:
                    px[x, y] = MIOLO
                    continue
                faixa = prof / 15 * (len(PALETA_FOGO) - 1)
                i = int(faixa)
                # dithering leve entre faixas vizinhas
                if (x + y) % 2 == 0 and faixa - i > 0.5 and i + 1 < len(PALETA_FOGO):
                    i += 1
                px[x, y] = PALETA_FOGO[len(PALETA_FOGO) - 1 - min(i, len(PALETA_FOGO) - 1)] \
                    if False else PALETA_FOGO[min(len(PALETA_FOGO) - 1, int(faixa + (0.5 if (x + y) % 2 == 0 else 0)))]
        # brasas soltas
        for _ in range(5):
            ex = int(borda + 3 + rnd.random() * 5) if False else rnd.randint(24, tam - 1)
            ey = rnd.randrange(tam)
            if px[ex, ey][3] == 0:
                px[ex, ey] = PALETA_FOGO[rnd.choice((4, 5))]
        # inverte a paleta: ponta escura (vermelho) -> centro claro
        sheet.paste(im.resize((tam * esc, tam * esc), Image.NEAREST), (f * tam * esc, 0))
    sheet.save(os.path.join(SAIDA, "fogo_sheet.png"))
    return sheet


def brilho(larg=180, alt=540):
    """Gradiente avermelhado (alfa decrescente) que ilumina o cenário à frente do fogo."""
    im = Image.new("RGBA", (larg, alt), (0, 0, 0, 0))
    px = im.load()
    for x in range(larg):
        a = int(110 * (1 - x / larg) ** 2)
        for y in range(alt):
            px[x, y] = (255, 110, 20, a)
    im.save(os.path.join(SAIDA, "brilho_fogo.png"))


if __name__ == "__main__":
    os.makedirs(SAIDA, exist_ok=True)
    caixote(); espinhos(); barreira()
    fogo(); brilho()
    print("ok")
