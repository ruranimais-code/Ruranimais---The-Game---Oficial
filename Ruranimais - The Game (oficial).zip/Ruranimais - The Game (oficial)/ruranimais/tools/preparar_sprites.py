
#Recorta as spritesheets do personagem

import os
import numpy as np
from PIL import Image
from scipy import ndimage

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIG = os.path.join(RAIZ, "arte_original")
SAIDA = os.path.join(RAIZ, "assets", "jogador")

# nome -> (arquivo, colunas, linhas, escala final)
# A sheet de corrida foi desenhada um pouco maior que as outras, por isso a escala menor.
SHEETS = {
    "correr":  ("corrida.jpeg", 6, 1, 0.34),
    "pulo":    ("salto.jpeg",   4, 2, 0.285),
    "ataque":  ("ataque.jpeg",  4, 2, 0.285),
    "deslize": ("deslize.jpeg", 4, 2, 0.285),
}
EROSAO = 4
LIMIAR_FUNDO = 14  # pixels com canal máximo <= isso e ligados à borda = fundo


def remover_fundo(rgb):
    """Devolve RGBA. O fundo é o preto puro conectado às bordas da célula.

    Os contornos do personagem também são pretos, então um flood-fill simples
    vazaria para dentro do corpo por brechas finas. Para evitar isso, o preto é
    erodido antes de rotular (brechas finas desaparecem) e depois dilatado de
    volta só um pouco, sempre restrito aos pixels escuros.
    """
    escuro = rgb.max(axis=2) <= LIMIAR_FUNDO
    nucleo = ndimage.binary_erosion(escuro, iterations=EROSAO, border_value=1)
    rotulos, _ = ndimage.label(nucleo)
    na_borda = set(np.unique(np.concatenate(
        [rotulos[0, :], rotulos[-1, :], rotulos[:, 0], rotulos[:, -1]])))
    na_borda.discard(0)
    fundo = np.isin(rotulos, list(na_borda))
    fundo = ndimage.binary_dilation(fundo, iterations=EROSAO - 1, mask=escuro | fundo)
    # come o "halo" escuro do JPEG logo na borda
    halo = ndimage.binary_dilation(fundo, iterations=1) & (rgb.max(axis=2) <= 40)
    fundo = fundo | halo
    alfa = np.where(fundo, 0, 255).astype(np.uint8)
    return np.dstack([rgb, alfa])


def main():
    os.makedirs(SAIDA, exist_ok=True)
    for nome, (arq, cols, lins, escala) in SHEETS.items():
        img = np.array(Image.open(os.path.join(ORIG, arq)).convert("RGB"))
        H, W, _ = img.shape
        cw, ch = W / cols, H / lins
        quadros = []
        for r in range(lins):
            for c in range(cols):
                x0, x1 = int(round(c * cw)), int(round((c + 1) * cw))
                y0, y1 = int(round(r * ch)), int(round((r + 1) * ch))
                quadros.append(remover_fundo(img[y0:y1, x0:x1]))
        # recorte comum (união das caixas) para manter a posição relativa entre quadros
        caixas = []
        for q in quadros:
            ys, xs = np.where(q[..., 3] > 0)
            caixas.append((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
        ux0 = min(b[0] for b in caixas); uy0 = min(b[1] for b in caixas)
        ux1 = max(b[2] for b in caixas); uy1 = max(b[3] for b in caixas)
        for i, q in enumerate(quadros):
            im = Image.fromarray(q[uy0:uy1, ux0:ux1], "RGBA")
            novo = (max(1, round(im.width * escala)), max(1, round(im.height * escala)))
            im = im.resize(novo, Image.LANCZOS)
            im.save(os.path.join(SAIDA, f"{nome}_{i}.png"))
        print(nome, len(quadros), "quadros", novo)


if __name__ == "__main__":
    main()
