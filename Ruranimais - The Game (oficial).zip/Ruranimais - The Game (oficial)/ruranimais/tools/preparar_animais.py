
# Converte a arte .piskel nos PNGs que o jogo usa:

#Animações: correr, parado, pulo, deslize.

import base64
import glob
import io
import json
import os
import shutil

from PIL import Image

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIG = os.path.join(RAIZ, "arte_original_v2")
SAIDA = os.path.join(RAIZ, "assets", "animais")
OBJ = os.path.join(RAIZ, "assets", "objetos")
MENU = os.path.join(RAIZ, "assets", "menu")
ESCALA = 4
TAM = 32

# ---------------------------------------------------------------- cores das skins
# cor original -> cor nova. As cores não citadas (contorno, olhos, língua) ficam como estão.
CACH = {"corpo": (172, 117, 85), "mancha": (125, 84, 74), "orelha": (79, 51, 48),
        "claro1": (176, 132, 107), "claro2": (196, 160, 139), "pata": (157, 156, 155),
        "sombra": (132, 127, 122)}
GATO = {"corpo": (102, 95, 94), "lista": (82, 75, 74), "meio": (91, 84, 83), "escuro": (67, 62, 61),
        "pata": (157, 156, 155), "sombra": (132, 127, 122), "orelha": (153, 127, 124),
        "claro1": (173, 152, 145), "claro2": (173, 164, 161)}

SKINS_CORES = {
    "cachorro": {
        "caramelo": {},
        "golden": {CACH["corpo"]: (224, 172, 86), CACH["mancha"]: (196, 140, 62), CACH["orelha"]: (176, 120, 52),
                   CACH["claro1"]: (238, 198, 124), CACH["claro2"]: (250, 224, 164), CACH["pata"]: (244, 222, 170),
                   CACH["sombra"]: (214, 186, 130)},
        "pastor": {CACH["corpo"]: (186, 136, 72), CACH["mancha"]: (40, 32, 30), CACH["orelha"]: (34, 28, 28),
                   CACH["claro1"]: (206, 160, 96), CACH["claro2"]: (224, 184, 120), CACH["pata"]: (150, 110, 70),
                   CACH["sombra"]: (110, 80, 50)},
        "dalmata": {CACH["corpo"]: (240, 238, 232), CACH["mancha"]: (52, 48, 52), CACH["orelha"]: (44, 40, 44),
                    CACH["claro1"]: (250, 250, 246), CACH["claro2"]: (255, 255, 252), CACH["pata"]: (214, 212, 208),
                    CACH["sombra"]: (196, 194, 190)},
        "husky": {CACH["corpo"]: (118, 128, 144), CACH["mancha"]: (84, 92, 108), CACH["orelha"]: (62, 68, 82),
                  CACH["claro1"]: (226, 232, 240), CACH["claro2"]: (248, 250, 252), CACH["pata"]: (236, 240, 246),
                  CACH["sombra"]: (170, 178, 190)},
    },
    "gato": {
        "cinza": {},
        "laranja": {GATO["corpo"]: (226, 142, 60), GATO["lista"]: (176, 96, 34), GATO["meio"]: (202, 118, 46),
                    GATO["escuro"]: (132, 70, 26), GATO["claro1"]: (244, 196, 140), GATO["claro2"]: (250, 220, 176),
                    GATO["pata"]: (250, 232, 200), GATO["sombra"]: (214, 170, 120)},
        "preto": {GATO["corpo"]: (66, 64, 74), GATO["lista"]: (46, 44, 54), GATO["meio"]: (56, 54, 64),
                  GATO["escuro"]: (36, 34, 44), GATO["claro1"]: (120, 108, 112), GATO["claro2"]: (132, 126, 130),
                  GATO["pata"]: (96, 92, 100), GATO["sombra"]: (86, 82, 90)},
        "siames": {GATO["corpo"]: (228, 208, 176), GATO["lista"]: (122, 88, 66), GATO["meio"]: (178, 142, 112),
                   GATO["escuro"]: (86, 62, 50), GATO["claro1"]: (240, 226, 204), GATO["claro2"]: (248, 238, 222),
                   GATO["pata"]: (110, 80, 62), GATO["sombra"]: (200, 176, 146)},
        "branco": {GATO["corpo"]: (238, 236, 232), GATO["lista"]: (206, 202, 202), GATO["meio"]: (220, 216, 216),
                   GATO["escuro"]: (176, 170, 176), GATO["claro1"]: (250, 244, 240), GATO["claro2"]: (252, 250, 248),
                   GATO["pata"]: (252, 250, 248), GATO["sombra"]: (214, 210, 210)},
    },
}


# -------------------------------------------------------------------- leitura .piskel
def ler_piskel(caminho):
    """Devolve (nome, fps, [quadros 32x32 RGBA]) com as camadas já juntas."""
    pk = json.load(open(caminho, encoding="utf-8"))["piskel"]
    w, h = pk["width"], pk["height"]
    total = None
    n = 0
    for L in pk["layers"]:
        l = json.loads(L)
        n = l["frameCount"]
        faixa = Image.new("RGBA", (w * n, h), (0, 0, 0, 0))
        for ch in l["chunks"]:
            png = Image.open(io.BytesIO(base64.b64decode(ch["base64PNG"].split(",", 1)[1]))).convert("RGBA")
            indices = [i for col in ch["layout"] for i in col]
            for k, i in enumerate(indices):
                faixa.paste(png.crop((k * w, 0, (k + 1) * w, h)), (i * w, 0))
        total = faixa if total is None else Image.alpha_composite(total, faixa)
    quadros = [total.crop((i * w, 0, (i + 1) * w, h)) for i in range(n)]
    return pk["name"], pk.get("fps", 8), quadros


def achar(prefixo):
    arqs = sorted(glob.glob(os.path.join(ORIG, prefixo + "*.piskel")))
    return ler_piskel(arqs[-1]) if arqs else None


# ------------------------------------------------------------------ placeholders
def achatar(q, altura=0.5, largura=1.1):
    """Deslize provisório: o quadro de corrida achatado, com os pés no chão."""
    bb = q.getbbox()
    corpo = q.crop(bb)
    nw, nh = max(1, round(corpo.width * largura)), max(1, round(corpo.height * altura))
    corpo = corpo.resize((nw, nh), Image.NEAREST)
    novo = Image.new("RGBA", (TAM, TAM), (0, 0, 0, 0))
    x = min(TAM - nw, max(0, bb[0] - (nw - corpo.width) // 2 if nw > bb[2] - bb[0] else bb[0]))
    novo.paste(corpo, (x, bb[3] - nh), corpo)
    return novo


# ---------------------------------------------------------------------- recolor
def recolorir(q, troca):
    if not troca:
        return q
    q = q.copy()
    px = q.load()
    for y in range(q.height):
        for x in range(q.width):
            r, g, b, a = px[x, y]
            nova = troca.get((r, g, b))
            if a and nova:
                px[x, y] = (*nova, a)
    return q


def ampliar(q):
    return q.resize((q.width * ESCALA, q.height * ESCALA), Image.NEAREST)


# ------------------------------------------------------------------------ main
def montar_animais():
    shutil.rmtree(SAIDA, ignore_errors=True)
    info = {}
    placeholders = []
    fontes = {
        "gato": {"correr": achar("gato_correndo"), "parado": achar("gato_parado"),
                 "pulo": achar("gato_pulo"), "deslize": achar("gato_deslize")},
        "cachorro": {"correr": achar("cachorro_correndo"), "parado": achar("cachorro_parado"),
                     "pulo": achar("cachorro_pulo"), "deslize": achar("cachorro_deslize")},
    }
    for animal, anims in fontes.items():
        correr = anims["correr"][2]
        quadros = {}
        fps = {}
        for nome, dado in anims.items():
            if dado:
                quadros[nome], fps[nome] = dado[2], dado[1]
        if "deslize" not in quadros:
            idx = [len(correr) - 1, len(correr) - 2] if animal == "gato" else [0, 1]
            quadros["deslize"] = [achatar(correr[i]) for i in idx]
            fps["deslize"] = 8
            placeholders.append(f"{animal}: deslize")
        if "pulo" not in quadros:
            ordem = [0, 0, 1, 3, 3, 2]                      # quadros de corrida que parecem "no ar"
            quadros["pulo"] = [correr[i % len(correr)] for i in ordem]
            fps["pulo"] = 8
            placeholders.append(f"{animal}: pulo")
        info[animal] = {k: {"quadros": len(v), "fps": fps[k]} for k, v in quadros.items()}

        for skin, troca in SKINS_CORES[animal].items():
            pasta = os.path.join(SAIDA, animal, skin)
            os.makedirs(pasta)
            for nome, lista in quadros.items():
                for i, q in enumerate(lista):
                    ampliar(recolorir(q, troca)).save(os.path.join(pasta, f"{nome}_{i}.png"))
    json.dump(info, open(os.path.join(SAIDA, "info.json"), "w", encoding="utf-8"), indent=1)
    return placeholders


def montar_comidas():
    nome, fps, quadros = achar("comida")
    for f in glob.glob(os.path.join(OBJ, "comida_*.png")):
        os.remove(f)
    for i, q in enumerate(quadros):
        bb = q.getbbox()
        recorte = q.crop((bb[0] - 1, bb[1] - 1, bb[2] + 1, bb[3] + 1))
        ampliar(recorte).save(os.path.join(OBJ, f"comida_{i}.png"))
    return len(quadros)


# ----------------------------------------------------------------- botão da loja
LETRAS = {  # fonte 5x7
    "L": ["X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"],
    "O": [".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX."],
    "J": ["..XXX", "...X.", "...X.", "...X.", "...X.", "X..X.", ".XX.."],
    "A": [".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"],
}


def montar_botao_loja():
    base = Image.open(os.path.join(MENU, "botao2.png")).convert("RGB")
    fundo = (245, 224, 174)
    b = base.copy()
    miolo = Image.new("RGB", (364, 38), fundo)
    b.paste(miolo, (22, 13))
    tinta = (8, 2, 2)
    px = b.load()
    esc, esp = 3, 3
    texto = "LOJA"
    larg = len(texto) * 5 * esc + (len(texto) - 1) * esp
    x0, y0 = 150, 22
    for k, ch in enumerate(texto):
        gx = x0 + k * (5 * esc + esp)
        for r, linha in enumerate(LETRAS[ch]):
            for c, v in enumerate(linha):
                if v == "X":
                    for dy in range(esc):
                        for dx in range(esc):
                            px[gx + c * esc + dx, y0 + r * esc + dy] = tinta
    # ícone de comida no lugar da estrela
    f = Image.open(os.path.join(OBJ, "comida_0.png")).convert("RGBA")
    f = f.resize((f.width * 3 // 4, f.height * 3 // 4), Image.NEAREST)
    b.paste(f, (332, 33 - f.height // 2), f)
    b.save(os.path.join(MENU, "botao_loja.png"))


if __name__ == "__main__":
    os.makedirs(OBJ, exist_ok=True)
    ph = montar_animais()
    n = montar_comidas()
    montar_botao_loja()
    print("comidas:", n)
    print("PLACEHOLDERS (troque quando tiver a arte):", ", ".join(ph) or "nenhum")
