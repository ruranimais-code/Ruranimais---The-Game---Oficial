#Carrega imagens, animações e sons

import glob
import json
import os

import pygame

import config as C

RAIZ = os.path.dirname(os.path.abspath(__file__))
A = os.path.join(RAIZ, "assets")

ANIMACOES = ("correr", "parado", "pulo", "deslize")


def _img(*partes, cor_reserva=(255, 0, 255), tam=(32, 32)):
    caminho = os.path.join(A, *partes)
    try:
        return pygame.image.load(caminho).convert_alpha()
    except (pygame.error, FileNotFoundError):
        s = pygame.Surface(tam, pygame.SRCALPHA)
        s.fill(cor_reserva)
        return s


def _opaca(*partes):
    caminho = os.path.join(A, *partes)
    try:
        return pygame.image.load(caminho).convert()
    except (pygame.error, FileNotFoundError):
        s = pygame.Surface((C.LARGURA, C.ALTURA))
        s.fill((60, 120, 60))
        return s


class Sons:
    def __init__(self):
        self.ok = False
        self.efeitos = {}
        self.musica = None
        try:
            pygame.mixer.init()
            self.ok = True
        except pygame.error:
            return
        for nome in ("pulo", "pouso", "deslizar", "batida", "comida", "fim",
                     "menu_move", "menu_ok", "conquista", "compra", "negado"):
            try:
                self.efeitos[nome] = pygame.mixer.Sound(os.path.join(A, "sons", nome + ".wav"))
                self.efeitos[nome].set_volume(C.VOLUME_EFEITOS)
            except (pygame.error, FileNotFoundError):
                pass
        try:
            self.musica = pygame.mixer.Sound(os.path.join(A, "sons", "musica.wav"))
            self.musica.set_volume(C.VOLUME_MUSICA)
        except (pygame.error, FileNotFoundError):
            pass
        self._canal_musica = None

    def tocar(self, nome, ligado=True):
        if self.ok and ligado and nome in self.efeitos:
            self.efeitos[nome].play()

    def pausar(self, pausado):
        """Congela / retoma todos os sons (usado na tela de pausa)."""
        if self.ok:
            (pygame.mixer.pause if pausado else pygame.mixer.unpause)()

    def musica_ligar(self, ligado):
        if not (self.ok and self.musica):
            return
        if ligado:
            if self._canal_musica is None or not self._canal_musica.get_busy():
                self._canal_musica = self.musica.play(loops=-1)
        else:
            self.musica.stop()
            self._canal_musica = None


class Imagens:
    def __init__(self):
        # ---- bichinhos: carregados sob demanda por (animal, skin); veja quadros()
        self._cache_animais = {}
        try:
            with open(os.path.join(A, "animais", "info.json"), encoding="utf-8") as f:
                self.info_anim = json.load(f)
        except (OSError, ValueError):
            self.info_anim = {}

        # ---- obstáculos
        self.caixote = _img("objetos", "caixote.png", tam=C.CAIXOTE)
        self.espinhos = _img("objetos", "espinhos.png", tam=C.ESPINHOS)
        self.barreira = _img("objetos", "barreira.png", tam=C.BARREIRA)

        # ---- comidas (6 desenhos)
        self.comidas = [_img("objetos", f"comida_{i}.png", cor_reserva=(240, 160, 40),
                             tam=(C.COMIDA_TAM, C.COMIDA_TAM))
                        for i in range(C.COMIDA_VARIANTES)]

        # ---- fogo
        sheet = _img("objetos", "fogo_sheet.png", cor_reserva=(240, 120, 20), tam=(512, 64))
        self.fogo = [sheet.subsurface((i * 64, 0, 64, 64)).copy() for i in range(sheet.get_width() // 64)]
        self.brilho_fogo = _img("objetos", "brilho_fogo.png", cor_reserva=(255, 100, 20, 60), tam=(180, 540))

        # ---- cenários
        nomes = ("inicial", "2", "3", "4", "5")
        self.cen_corpo = {n: _opaca("cenarios", f"corpo_{n}.png") for n in nomes}
        self.cen_inteiro = {n: _opaca("cenarios", f"inteiro_{n}.png") for n in nomes}
        self.cen_trans = {}
        for arq in glob.glob(os.path.join(A, "cenarios", "trans_*.png")):
            base = os.path.basename(arq)[6:-4]            # "a_b"
            a, b = base.split("_")
            self.cen_trans[(a, b)] = pygame.image.load(arq).convert()

        # ---- menu
        self.banner = _opaca("menu", "banner.png")
        # ordem no menu: Iniciar, Loja, Conquistas, Configurações
        self.botoes = [_img("menu", nome, tam=(394, 66))
                       for nome in ("botao1.png", "botao_loja.png", "botao2.png", "botao3.png")]


def _quadros_do_bichinho(animal, skin, anim):
    """Carrega assets/animais/<animal>/<skin>/<anim>_<n>.png (na ordem de n)."""
    arqs = sorted(glob.glob(os.path.join(A, "animais", animal, skin, f"{anim}_*.png")),
                  key=lambda p: int(os.path.basename(p).rsplit("_", 1)[1].split(".")[0]))
    quadros = []
    for p in arqs:
        try:
            quadros.append(pygame.image.load(p).convert_alpha())
        except (pygame.error, FileNotFoundError):
            pass
    return quadros


def _reserva_bichinho():
    s = pygame.Surface((C.SPRITE_TAM, C.SPRITE_TAM), pygame.SRCALPHA)
    pygame.draw.rect(s, (230, 110, 40), (32, 40, 64, 88))
    return [s]


def quadros_do_bichinho(imagens, animal, skin):
    """dict animação -> lista de quadros (em cache). Animação que faltar usa 'correr'."""
    chave = (animal, skin)
    if chave not in imagens._cache_animais:
        d = {a: _quadros_do_bichinho(animal, skin, a) for a in ANIMACOES}
        base = d["correr"] or d["parado"] or _reserva_bichinho()
        for a in ANIMACOES:
            if not d[a]:
                d[a] = base
        imagens._cache_animais[chave] = d
    return imagens._cache_animais[chave]


def fps_da_animacao(imagens, animal, anim):
    if anim == "correr":
        return C.FPS_CORRER
    if anim == "deslize":
        return C.FPS_DESLIZE
    return imagens.info_anim.get(animal, {}).get(anim, {}).get("fps", 7)


def quadro_da_animacao(quadros, t, fps, loop=True):
    i = int(t * fps)
    if loop:
        return quadros[i % len(quadros)]
    return quadros[min(i, len(quadros) - 1)]
