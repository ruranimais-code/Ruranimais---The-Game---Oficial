# Lógica do jogo (jogador, obstáculos, comidas, parede de fogo, geração infinita de trechos e contagem de metros)

import math
import random

import config as C


# ------------------------------------------------------------------ retângulos
def colide(a, b):
    """Interseção de dois retângulos (x, y, w, h). Encostar não conta."""
    return (a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and
            a[1] < b[1] + b[3] and b[1] < a[1] + a[3])


# ------------------------------------------------------------------ obstáculos
class Obstaculo:
    """Um objeto fixo no mundo. `x` é a borda esquerda; a base fica no chão."""

    def __init__(self, tipo, x):
        self.tipo = tipo            # "caixote" | "espinhos" | "barreira"
        self.x = float(x)
        self.ativo = True           # False depois de bater (não colide mais)
        w, h = {"caixote": C.CAIXOTE, "espinhos": C.ESPINHOS, "barreira": C.BARREIRA}[tipo]
        self.w, self.h = w, h
        self.y = C.CHAO_Y - h

    @property
    def rect(self):
        return (self.x, self.y, self.w, self.h)

    @property
    def topo(self):
        return self.y

    def hitboxes(self):
        """Áreas que machucam (ou bloqueiam)."""
        if not self.ativo:
            return []
        x, y = self.x, self.y
        if self.tipo == "caixote":
            return [(x, y, self.w, self.h)]
        if self.tipo == "espinhos":
            return [(x + 6, y + 10, self.w - 12, self.h - 12)]
        # barreira: só a tábua de cima é sólida. As pernas ficam de fora de propósito: a barreira é
        # vista "de frente", então quem desliza passa por entre as pernas, por baixo da tábua
        # (vão livre de ~51 px). Em pé ou pulando baixo, o jogador bate na tábua.
        # (10 px de folga em cada ponta, onde ficam as luzinhas: deixa o pulo por cima mais justo)
        return [(x + 10, y, self.w - 20, 21)]


# ---------------------------------------------------------------------- comida
class Comida:
    """Uma comidinha flutuando no mundo. (cx, cy) é o centro. Basta encostar para pegar."""

    def __init__(self, cx, cy, variante):
        self.cx, self.cy = float(cx), float(cy)
        self.variante = variante    # qual dos desenhos de comida
        self.ativo = True

    @property
    def hitbox(self):
        t = C.COMIDA_HITBOX
        return (self.cx - t / 2, self.cy - t / 2, t, t)


# --------------------------------------------------------------------- jogador
class Jogador:
    def __init__(self):
        self.x = 0.0                 # mundo
        self.y = float(C.CHAO_Y)     # pés
        self.vy = 0.0
        self.no_chao = True
        self.apoio = None            # caixote em que está em cima
        self.deslizando = False
        self.t_deslize = 0.0
        self.recarga_deslize = 0.0
        self.querendo_deslizar = False
        self.invulneravel = 0.0
        self.coyote = 0.0
        self.buffer_pulo = 0.0
        self.pulo_segurado = False
        self.t_pouso = 0.0           # animação curta de pouso
        self.t_anim = 0.0

    # tamanho atual da caixa de colisão
    def caixa(self):
        w, h = C.HITBOX_DESLIZE if self.deslizando else C.HITBOX_EM_PE
        x = self.x - (w / 2 if not self.deslizando else w * 0.45)
        return (x, self.y - h, w, h)

    def caixa_em_pe(self):
        w, h = C.HITBOX_EM_PE
        return (self.x - w / 2, self.y - h, w, h)


# ---------------------------------------------------------------------- partida
class Partida:
    """Uma corrida, do início até o fogo alcançar o jogador."""

    def __init__(self, semente=None):
        self.rnd = random.Random(semente)
        self.j = Jogador()
        self.obstaculos = []
        self.comidas = []
        self.eventos = []            # lista de (nome, dados); o main consome e limpa
        self.tempo = 0.0
        self.velocidade = C.VELOCIDADE_INICIAL
        self.dist_fogo = C.FOGO_DIST_INICIAL
        self.fim = False
        self.comidas_pegas = 0
        self.lista_comidas = []      # variante de cada comida pega (para os efeitos)
        self.erros = 0
        self.metros_sem_erro_desde = 0.0
        self.stats = dict(pulos=0, deslizes=0, caixotes=0, erros=0, comidas=0,
                          pior_fogo=C.FOGO_DIST_INICIAL)
        # geração
        self._proximo_x = 900.0
        self._desde_campo = 0
        # um aquecimento: fileira no chão e um arco que ensina a pular
        self._comida_linha(520, 4, 36)
        self._comida_arco(720, 5, 90, 135)

    # ---------------------------------------------------------------- helpers
    @property
    def metros(self):
        return max(0, self.j.x) / C.PX_POR_METRO

    @property
    def metros_inteiros(self):
        return int(self.metros)

    @property
    def moedas(self):
        """Quanto esta corrida rendeu para gastar na loja."""
        return self.comidas_pegas * C.VALOR_COMIDA

    @property
    def camera_x(self):
        return self.j.x - C.JOGADOR_TELA_X

    def _ev(self, nome, **dados):
        self.eventos.append((nome, dados))

    # ------------------------------------------------------------------ ações
    def pedir_pulo(self):
        self.j.buffer_pulo = C.TEMPO_BUFFER_PULO
        self.j.pulo_segurado = True

    def soltar_pulo(self):
        self.j.pulo_segurado = False
        if self.j.vy < -300:                  # pulo variável: soltar cedo = pulo menor
            self.j.vy *= C.CORTE_PULO

    def deslizar(self, apertado):
        self.j.querendo_deslizar = apertado

    # ------------------------------------------------------------------ update
    def atualizar(self, dt):
        if self.fim:
            return
        j = self.j
        self.tempo += dt
        j.t_anim += dt

        # velocidade cresce devagar com a distância
        self.velocidade = min(C.VELOCIDADE_MAXIMA,
                              C.VELOCIDADE_INICIAL + self.metros * C.GANHO_POR_METRO)

        self._atualizar_acoes(dt)
        self._mover(dt)
        self._colisoes_perigo()
        self._coletar()
        self._fogo(dt)
        self._gerar()
        self._limpar()

    # ---- pulo / deslize
    def _atualizar_acoes(self, dt):
        j = self.j
        j.invulneravel = max(0.0, j.invulneravel - dt)
        j.recarga_deslize = max(0.0, j.recarga_deslize - dt)
        j.buffer_pulo = max(0.0, j.buffer_pulo - dt)
        j.t_pouso = max(0.0, j.t_pouso - dt)
        j.coyote = C.TEMPO_COYOTE if j.no_chao else max(0.0, j.coyote - dt)

        # deslizar
        if j.deslizando:
            j.t_deslize += dt
            pode_levantar = not self._bateria_se_levantar()
            acabou = (not j.querendo_deslizar) or j.t_deslize >= C.DESLIZE_MAX
            if acabou and pode_levantar:
                j.deslizando = False
                j.recarga_deslize = C.DESLIZE_RECARGA
        elif j.querendo_deslizar and j.no_chao and j.recarga_deslize <= 0.0:
            j.deslizando = True
            j.t_deslize = 0.0
            self.stats["deslizes"] += 1
            self._ev("deslizar")

        # pular (com buffer e coyote)
        if j.buffer_pulo > 0 and (j.no_chao or j.coyote > 0):
            if j.deslizando and self._bateria_se_levantar():
                return  # sem espaço para se levantar embaixo da barreira
            j.deslizando = False
            j.vy = -C.VEL_PULO
            j.no_chao = False
            j.apoio = None
            j.coyote = 0.0
            j.buffer_pulo = 0.0
            self.stats["pulos"] += 1
            self._ev("pulo")
            if not j.pulo_segurado:      # tecla já foi solta: pulo curto
                j.vy *= C.CORTE_PULO

    def _bateria_se_levantar(self):
        """True se, ao ficar em pé agora, o jogador bateria em algo."""
        caixa = self.j.caixa_em_pe()
        for o in self.obstaculos:
            if o.tipo == "barreira" and o.ativo:
                for h in o.hitboxes():
                    if colide(caixa, h):
                        return True
        return False

    # ---- movimento e chão
    def _mover(self, dt):
        j = self.j
        j.x += self.velocidade * dt
        pes_antes = j.y
        caixa_x = self.j.caixa()

        if not j.no_chao:
            g = C.GRAVIDADE
            if j.querendo_deslizar and j.vy > 0:
                g += C.QUEDA_RAPIDA
            j.vy += g * dt
            j.y += j.vy * dt
        # superfície mais alta que está abaixo (ou na altura) dos pés
        chao = float(C.CHAO_Y)
        apoio = None
        for o in self.obstaculos:
            if o.tipo != "caixote" or not o.ativo:
                continue
            if caixa_x[0] < o.x + o.w and o.x < caixa_x[0] + caixa_x[2]:
                if o.topo >= pes_antes - 10 and o.topo < chao:
                    chao, apoio = o.topo, o
        if j.y >= chao and j.vy >= 0:
            if not j.no_chao:
                j.t_pouso = 0.12
                self._ev("pouso", caixote=apoio is not None)
                if apoio is not None:
                    self.stats["caixotes"] += 1
                    self._ev("caixote")
            j.y, j.vy, j.no_chao, j.apoio = chao, 0.0, True, apoio
        elif j.no_chao and j.y < chao - 0.5:
            # saiu da borda do caixote: cai
            j.no_chao = False
            j.apoio = None

    # ---- batidas
    def _colisoes_perigo(self):
        j = self.j
        caixa = j.caixa()
        for o in self.obstaculos:
            if not o.ativo:
                continue
            if o.x > j.x + 200 or o.x + o.w < j.x - 200:
                continue
            for h in o.hitboxes():
                if colide(caixa, h):
                    if o.tipo == "caixote" and j.y <= o.topo + 10 and j.vy >= 0:
                        continue   # está pousando em cima, não é batida
                    if j.invulneravel > 0:
                        # atravessa sem dano; não deixa o objeto "grudar"
                        break
                    self._bater(o)
                    return

    def _bater(self, o):
        j = self.j
        o.ativo = False
        j.invulneravel = C.INVULNERAVEL
        self.dist_fogo -= C.FOGO_PENALIDADE
        self.stats["erros"] += 1
        self.erros += 1
        self.metros_sem_erro_desde = j.x
        self._ev("batida", tipo=o.tipo, x=o.x, y=o.y)

    # ---- comidas: encostou, pegou (sem apertar nada)
    def _coletar(self):
        caixa = self.j.caixa()
        for c in self.comidas:
            if not c.ativo or abs(c.cx - self.j.x) > 150:
                continue
            if colide(caixa, c.hitbox):
                c.ativo = False
                self.comidas_pegas += 1
                self.stats["comidas"] += 1
                self.lista_comidas.append(c.variante)
                self.dist_fogo = min(C.FOGO_DIST_MAXIMA, self.dist_fogo + C.FOGO_BONUS_COMIDA)
                self._ev("comida", x=c.cx, y=c.cy, variante=c.variante, total=self.comidas_pegas)

    # ---- fogo
    def _fogo(self, dt):
        self.dist_fogo = min(C.FOGO_DIST_MAXIMA, self.dist_fogo - C.FOGO_AVANCO * dt)
        self.stats["pior_fogo"] = min(self.stats["pior_fogo"], self.dist_fogo)
        if self.dist_fogo <= C.FOGO_DISTANCIA_MORTE:
            self.fim = True
            self._ev("fim")

    # ---- geração infinita de trechos
    def _gerar(self):
        limite = self.camera_x + C.LARGURA + 400
        while self._proximo_x < limite:
            self._proximo_x = self._criar_trecho(self._proximo_x)

    # fileiras de comida --------------------------------------------------------
    def _comida_linha(self, x, n, altura, passo=None):
        """n comidas em linha reta, `altura` px acima do chão (centro da comida)."""
        passo = passo or C.COMIDA_ESPACO
        v = self.rnd.randrange(C.COMIDA_VARIANTES)
        for i in range(n):
            self.comidas.append(Comida(x + i * passo, C.CHAO_Y - altura, v))

    def _comida_arco(self, x_centro, n, base, pico):
        """n comidas em arco (como o caminho de um pulo) centrado em x_centro.
        As pontas ficam a `base` px do chão: de cima do chão ninguém alcança, só pulando."""
        passo = C.COMIDA_ESPACO
        v = self.rnd.randrange(C.COMIDA_VARIANTES)
        x0 = x_centro - passo * (n - 1) / 2
        for i in range(n):
            f = math.sin(math.pi * i / (n - 1)) if n > 1 else 1.0
            self.comidas.append(Comida(x0 + i * passo, C.CHAO_Y - (base + (pico - base) * f), v))

    def _criar_trecho(self, x):
        rnd = self.rnd
        m = x / C.PX_POR_METRO
        v = self.velocidade
        opcoes = ["caixote", "espinhos", "espinhos", "campo"]
        if m > 120:
            opcoes += ["barreira", "barreira", "caixote_espinhos", "caixotes2"]
        if m > 350:
            opcoes += ["barreira_espinhos", "espinhos2", "caixote_barreira"]
        # garante trechos só de comida com frequência (descanso + recompensa)
        if self._desde_campo >= 4:
            tipo = "campo"
        else:
            tipo = rnd.choice(opcoes)

        def novo(t, xx):
            o = Obstaculo(t, xx)
            self.obstaculos.append(o)
            return o

        def arco_sobre(x0, x1):
            self._comida_arco((x0 + x1) / 2, 5, 90, 135)

        fim = x
        if tipo == "caixote":
            novo("caixote", x); fim = x + C.CAIXOTE[0]
            self._comida_linha(x + 14, 2, C.CAIXOTE[1] + 30, 38)       # em cima do caixote
        elif tipo == "caixotes2":
            novo("caixote", x); novo("caixote", x + C.CAIXOTE[0])
            fim = x + 2 * C.CAIXOTE[0]
            self._comida_linha(x + 20, 3, C.CAIXOTE[1] + 30, 46)
        elif tipo == "espinhos":
            n = rnd.choice((1, 1, 2))
            for i in range(n):
                novo("espinhos", x + i * C.ESPINHOS[0])
            fim = x + n * C.ESPINHOS[0]
            arco_sobre(x, fim)
        elif tipo == "espinhos2":
            for i in range(3):
                novo("espinhos", x + i * C.ESPINHOS[0])
            fim = x + 3 * C.ESPINHOS[0]
            arco_sobre(x, fim)
        elif tipo == "barreira":
            novo("barreira", x); fim = x + C.BARREIRA[0]
            self._comida_linha(x + 16, 3, 24, 36)                     # sob a barreira: recompensa de quem desliza
        elif tipo == "caixote_espinhos":
            novo("caixote", x)
            novo("espinhos", x + C.CAIXOTE[0] + 70)
            fim = x + C.CAIXOTE[0] + 70 + C.ESPINHOS[0]
            self._comida_linha(x + 14, 2, C.CAIXOTE[1] + 30, 38)
        elif tipo == "caixote_barreira":
            novo("caixote", x)
            xb = x + C.CAIXOTE[0] + 170
            novo("barreira", xb)
            fim = xb + C.BARREIRA[0]
            self._comida_linha(x + 14, 2, C.CAIXOTE[1] + 30, 38)
            self._comida_linha(xb + 16, 3, 24, 36)
        elif tipo == "barreira_espinhos":
            novo("barreira", x)
            xs = x + C.BARREIRA[0] + int(v * 0.85)
            novo("espinhos", xs)
            fim = xs + C.ESPINHOS[0]
            self._comida_linha(x + 16, 3, 24, 36)
            arco_sobre(xs, fim)
        elif tipo == "campo":
            # trecho livre só com comida: fileira no chão, arco no ar ou onda
            forma = rnd.choice(("linha", "arco", "onda"))
            if forma == "linha":
                self._comida_linha(x, 6, 36)
                fim = x + 6 * C.COMIDA_ESPACO
            elif forma == "arco":
                self._comida_arco(x + 120, 6, 90, 140)
                fim = x + 6 * C.COMIDA_ESPACO
            else:
                self._comida_linha(x, 3, 36)
                self._comida_arco(x + 3 * C.COMIDA_ESPACO + 90, 5, 90, 135)
                fim = x + 3 * C.COMIDA_ESPACO + 90 + 3 * C.COMIDA_ESPACO

        self._desde_campo = 0 if tipo == "campo" else self._desde_campo + 1
        # às vezes sobra uma fileirinha no chão na folga entre os trechos
        folga = v * rnd.uniform(0.80, 1.30)
        if tipo != "campo" and rnd.random() < 0.45 and folga > 300:
            self._comida_linha(fim + 70, 3, 36)
        return fim + folga

    def _limpar(self):
        corte = self.j.x - 600
        self.obstaculos = [o for o in self.obstaculos if o.x + o.w > corte]
        self.comidas = [c for c in self.comidas if c.cx > corte]
