#Cenário infinito

import math

import config as C

# transições que existem em assets/cenarios/trans_<a>_<b>.png
LARGURA_TRECHO = C.LARGURA_CORPO_CENARIO + C.FAIXA_TRANSICAO


def sequencia_de_cenarios():
    """Gerador infinito de nomes de cenário, na ordem do ciclo."""
    # quantos "tijolos" de 4/5 cabem em METROS_MIOLO metros
    n_miolo = max(2, math.ceil(C.METROS_MIOLO * C.PX_POR_METRO / LARGURA_TRECHO))
    while True:
        yield "inicial"
        yield "2"
        yield "3"
        for i in range(n_miolo):
            yield "4" if i % 2 == 0 else "5"
        yield "3"


class Cenario:
    def __init__(self, imagens_corpo, imagens_trans, x_inicial=-420):
        """imagens_corpo: {nome: Surface}; imagens_trans: {(a, b): Surface}."""
        self.corpo = imagens_corpo
        self.trans = imagens_trans
        self.seq = sequencia_de_cenarios()
        self.trechos = []            # (x0, Surface)
        self._atual = next(self.seq)
        self._x = x_inicial
        self.nome_atual_em = []      # (x0, nome) para saber em que cenário estamos

    def _estender(self, ate_x):
        while self._x < ate_x:
            prox = next(self.seq)
            self.trechos.append((self._x, self.corpo[self._atual]))
            self.nome_atual_em.append((self._x, self._atual))
            self._x += self.corpo[self._atual].get_width()
            self.trechos.append((self._x, self.trans[(self._atual, prox)]))
            self._x += C.FAIXA_TRANSICAO
            self._atual = prox

    def nome_em(self, x_mundo):
        """Nome do cenário que está em x_mundo (útil para música/efeitos futuros)."""
        nome = None
        for x0, n in self.nome_atual_em:
            if x0 <= x_mundo:
                nome = n
        return nome

    def desenhar(self, tela, camera_x):
        self._estender(camera_x + C.LARGURA + 900)
        # descarta o que já ficou muito para trás
        while len(self.trechos) > 4 and self.trechos[0][0] + self.trechos[0][1].get_width() < camera_x - 300:
            self.trechos.pop(0)
        if len(self.nome_atual_em) > 6:
            self.nome_atual_em = self.nome_atual_em[-6:]
        for x0, img in self.trechos:
            sx = int(round(x0 - camera_x))
            if sx > C.LARGURA or sx + img.get_width() < 0:
                continue
            tela.blit(img, (sx, 0))
